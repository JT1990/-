﻿using Microsoft.SqlServer.Server;
using System.Configuration;
using System.Drawing;
using System.Net.NetworkInformation;
using System.Threading;
using System.Windows.Forms;

namespace Shot
{
    public class ScreenShot : Form
    {
        static private int pointX;
        static private int pointY;
        static private int m_width;
        static private int m_height;



        public ScreenShot()
        { 
            this.SetStyle(
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint,
                true);

            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            this.KeyPreview = true;

            Init();


        }

        public void SaveToClipboard(string fileName = "")
        {
            m_width = int.Parse(ConfigurationManager.AppSettings["m_width"]);
            m_height = int.Parse(ConfigurationManager.AppSettings["m_height"]);
            pointX = Screen.PrimaryScreen.Bounds.Width- m_width;
            pointY = Screen.PrimaryScreen.Bounds.Height - m_width;

            System.Console.WriteLine(pointX+":::"+pointY + ":::" + m_width + ":::" + m_height);
            var rect = new Rectangle(pointX, pointY, m_width, m_height);

            using (var img = new Bitmap(rect.Width, rect.Height))
            {
                using (var g = Graphics.FromImage(img))
                {
                    g.DrawImage(this.BackgroundImage,
                        new Rectangle(0, 0, rect.Width, rect.Height),
                        rect,
                        GraphicsUnit.Pixel);
                    if (string.IsNullOrEmpty(fileName))
                    {
                        Clipboard.SetImage(img);
                    }
                    else
                    {
                        img.Save(fileName);
                        System.Console.WriteLine("截图完成!");
                    }
                }
            }
        }


        private void Init()
        {
            var img = PrintScreen();
            this.BackgroundImage = img;
            Cursor = Cursors.Arrow;
        }

        private Image PrintScreen()
        {
            Image img = new Bitmap(this.Size.Width, this.Size.Height);
            var g = Graphics.FromImage(img);
            g.CopyFromScreen(new Point(0, 0), new Point(0, 0), this.Size);
            g.Dispose();
            return img;
        }


        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 255);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        public void SetWidth(int _width)
        {
            m_width = _width;
        }

        public void SetHeight(int _height)
        {
            m_height = _height;
        }
    }
}